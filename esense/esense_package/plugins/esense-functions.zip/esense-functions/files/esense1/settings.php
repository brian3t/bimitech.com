<?php
$hompage_title = 'Home';
$theme_menus = array( 
			   array("name"=>"Main menu", "location"=>"mainmenu"),
             ); 

?>