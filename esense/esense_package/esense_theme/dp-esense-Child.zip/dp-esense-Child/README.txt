This child theme is useful for simple overriding the files in the theme.

In order to override the theme CSS files we recommend to use the override.css file from the Advanced theme options.

Please remember to copy the images directory when you're overriding the CSS files!