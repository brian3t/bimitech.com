/**
 *
 * -------------------------------------------
 * Script for the contact page
 * -------------------------------------------
 *
 **/
 
 
jQuery(document).ready(function(){
	"use strict";
	jQuery("#contactForm").validate();
});