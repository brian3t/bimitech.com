=== DP Esense ===
Contributors: DynamicPress
Requires at least: WordPress 4.1
Tested up to: WordPress 4.3-trunk
Version: 1.0

== Changelog ==

= 1.0 =
* Released: December 18, 2015

Initial release
