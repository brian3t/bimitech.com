<?php

// This file was added especially for the wp-signup.php and wp-activate.php files :-)

esense_load('header');
esense_load('before');

// EOF