<?php

// disable direct access to the file	
defined('ESENSE_WP') or die('Access denied');	

// This file can be used to add new functions for the theme without overriding existing PHP files.

// EOF