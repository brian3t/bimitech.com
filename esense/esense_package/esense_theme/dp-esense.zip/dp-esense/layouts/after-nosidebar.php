<?php 
	
	/**
	 *
	 * Template elements after the page content
	 *
	 **/
	
	// create an access to the template main object
	// disable direct access to the file	
	defined('ESENSE_WP') or die('Access denied');
	
?>
		
			</div><!-- end of the #esense-content-wrap -->
			
			</section><!-- end of the mainbody section -->
		</section><!-- end of the #esense-mainbody-columns -->
</section><!-- end of the .esense-page-wrap section -->	


<div class="clearboth"></div>